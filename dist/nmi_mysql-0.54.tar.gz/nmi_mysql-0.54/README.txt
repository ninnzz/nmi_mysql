==========
nmi_mysql
==========

A simple and intuative mysql client wrapper for pymysql.
Ideal for performing simple and raw operations in mysql.

**Installation:**
*pip install nmi_mysql*

**Dependencies**
    * Python 3.4+
    * pymysql (http://www.pymysql.org/)

For full documentation and usage:
https://github.com/pprmint/nmi_mysql/blob/master/README.md 